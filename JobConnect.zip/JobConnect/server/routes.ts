import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertJobSchema, insertPostSchema, insertApplicationSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { calculateJobMatch, extractSkillsFromText } from "./openai";
import { validateWeb3Payment, estimateGasFee } from "./web3";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Generate JWT token
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
      
      res.json({ token, user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ message: "Registration failed", error: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
      
      res.json({ token, user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ message: "Login failed", error: error.message });
    }
  });

  // User routes
  app.get("/api/users/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ ...user, password: undefined });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user", error: error.message });
    }
  });

  app.put("/api/users/me", authenticateToken, async (req: any, res) => {
    try {
      const updates = req.body;
      delete updates.id;
      delete updates.createdAt;
      delete updates.updatedAt;
      
      const user = await storage.updateUser(req.user.userId, updates);
      res.json({ ...user, password: undefined });
    } catch (error) {
      res.status(400).json({ message: "Failed to update user", error: error.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ ...user, password: undefined, email: undefined });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user", error: error.message });
    }
  });

  // Job routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const { page = 1, limit = 20, skills, location, remote, search } = req.query;
      const offset = (Number(page) - 1) * Number(limit);
      
      let jobs;
      if (search) {
        jobs = await storage.searchJobs(String(search), skills ? String(skills).split(',') : []);
      } else {
        const filters = {
          skills: skills ? String(skills).split(',') : undefined,
          location: location ? String(location) : undefined,
          remote: remote === 'true' ? true : remote === 'false' ? false : undefined,
        };
        jobs = await storage.getJobs(Number(limit), offset, filters);
      }
      
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get jobs", error: error.message });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to get job", error: error.message });
    }
  });

  app.post("/api/jobs", authenticateToken, async (req: any, res) => {
    try {
      const jobData = insertJobSchema.parse(req.body);
      
      // Verify Web3 payment if required
      if (jobData.applicationFee && jobData.paymentTxHash) {
        const isValidPayment = await validateWeb3Payment(
          jobData.paymentTxHash, 
          jobData.applicationFee, 
          jobData.feeToken || 'ETH'
        );
        if (!isValidPayment) {
          return res.status(400).json({ message: "Invalid payment transaction" });
        }
      }
      
      const job = await storage.createJob({
        ...jobData,
        postedBy: req.user.userId,
      });
      
      res.json(job);
    } catch (error) {
      res.status(400).json({ message: "Failed to create job", error: error.message });
    }
  });

  app.put("/api/jobs/:id", authenticateToken, async (req: any, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      if (job.postedBy !== req.user.userId) {
        return res.status(403).json({ message: "Not authorized to update this job" });
      }
      
      const updates = req.body;
      delete updates.id;
      delete updates.createdAt;
      delete updates.updatedAt;
      delete updates.postedBy;
      
      const updatedJob = await storage.updateJob(req.params.id, updates);
      res.json(updatedJob);
    } catch (error) {
      res.status(400).json({ message: "Failed to update job", error: error.message });
    }
  });

  app.delete("/api/jobs/:id", authenticateToken, async (req: any, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      if (job.postedBy !== req.user.userId) {
        return res.status(403).json({ message: "Not authorized to delete this job" });
      }
      
      await storage.deleteJob(req.params.id);
      res.json({ message: "Job deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete job", error: error.message });
    }
  });

  // AI-powered job matching
  app.post("/api/jobs/:id/match", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      const job = await storage.getJob(req.params.id);
      
      if (!user || !job) {
        return res.status(404).json({ message: "User or job not found" });
      }
      
      const matchScore = await calculateJobMatch(user, job);
      res.json({ matchScore });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate match", error: error.message });
    }
  });

  // Posts routes
  app.get("/api/posts", async (req, res) => {
    try {
      const { page = 1, limit = 20 } = req.query;
      const offset = (Number(page) - 1) * Number(limit);
      
      const posts = await storage.getPosts(Number(limit), offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get posts", error: error.message });
    }
  });

  app.post("/api/posts", authenticateToken, async (req: any, res) => {
    try {
      const postData = insertPostSchema.parse(req.body);
      
      const post = await storage.createPost({
        ...postData,
        authorId: req.user.userId,
      });
      
      res.json(post);
    } catch (error) {
      res.status(400).json({ message: "Failed to create post", error: error.message });
    }
  });

  // Applications routes
  app.get("/api/applications/my", authenticateToken, async (req: any, res) => {
    try {
      const applications = await storage.getApplicationsByUser(req.user.userId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Failed to get applications", error: error.message });
    }
  });

  app.post("/api/applications", authenticateToken, async (req: any, res) => {
    try {
      const applicationData = insertApplicationSchema.parse(req.body);
      
      // Verify Web3 payment for application fee
      const job = await storage.getJob(applicationData.jobId!);
      if (job?.applicationFee && applicationData.paymentTxHash) {
        const isValidPayment = await validateWeb3Payment(
          applicationData.paymentTxHash, 
          job.applicationFee, 
          job.feeToken || 'ETH'
        );
        if (!isValidPayment) {
          return res.status(400).json({ message: "Invalid payment transaction" });
        }
      }
      
      // Calculate AI match score
      const user = await storage.getUser(req.user.userId);
      if (user && job) {
        const matchScore = await calculateJobMatch(user, job);
        applicationData.matchScore = Math.round(matchScore);
      }
      
      const application = await storage.createApplication({
        ...applicationData,
        applicantId: req.user.userId,
      });
      
      res.json(application);
    } catch (error) {
      res.status(400).json({ message: "Failed to create application", error: error.message });
    }
  });

  // AI skill extraction
  app.post("/api/ai/extract-skills", authenticateToken, async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) {
        return res.status(400).json({ message: "Text is required" });
      }
      
      const skills = await extractSkillsFromText(text);
      res.json({ skills });
    } catch (error) {
      res.status(500).json({ message: "Failed to extract skills", error: error.message });
    }
  });

  // Web3 utilities
  app.get("/api/web3/estimate-fee", async (req, res) => {
    try {
      const { token = 'ETH', amount = '0.001' } = req.query;
      const gasFee = await estimateGasFee(String(token), String(amount));
      res.json({ gasFee });
    } catch (error) {
      res.status(500).json({ message: "Failed to estimate fee", error: error.message });
    }
  });

  // Notifications
  app.get("/api/notifications", authenticateToken, async (req: any, res) => {
    try {
      const notifications = await storage.getNotificationsByUser(req.user.userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to get notifications", error: error.message });
    }
  });

  app.put("/api/notifications/:id/read", authenticateToken, async (req, res) => {
    try {
      await storage.markNotificationAsRead(req.params.id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification as read", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
