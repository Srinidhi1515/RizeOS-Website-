import OpenAI from "openai";
import { User, Job } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-openai-api-key"
});

export async function calculateJobMatch(user: User, job: Job): Promise<number> {
  try {
    const userProfile = `
      Name: ${user.name}
      Bio: ${user.bio || 'No bio provided'}
      Skills: ${user.skills.join(', ') || 'No skills listed'}
      Location: ${user.location || 'Not specified'}
    `;

    const jobDescription = `
      Title: ${job.title}
      Company: ${job.company}
      Description: ${job.description}
      Required Skills: ${job.skills.join(', ') || 'No specific skills required'}
      Location: ${job.location || 'Not specified'}
      Remote: ${job.remote ? 'Yes' : 'No'}
      Job Type: ${job.jobType}
    `;

    const prompt = `
      You are an AI recruitment specialist. Calculate a match score between a candidate and a job posting.
      
      Candidate Profile:
      ${userProfile}
      
      Job Posting:
      ${jobDescription}
      
      Consider these factors:
      1. Skill alignment (40% weight)
      2. Location compatibility (20% weight)
      3. Experience level from bio (20% weight)
      4. Job type preference (10% weight)
      5. Industry/domain match (10% weight)
      
      Respond with JSON containing:
      - matchScore: number between 0-100
      - reasons: array of strings explaining the score
      - skillsMatch: array of matching skills
      - recommendations: array of suggestions for improvement
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert AI recruiter that provides accurate job match scores based on candidate profiles and job requirements."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return Math.max(0, Math.min(100, result.matchScore || 0));

  } catch (error) {
    console.error('Job match calculation error:', error);
    // Return a basic match score based on skill intersection
    const userSkills = user.skills.map(s => s.toLowerCase());
    const jobSkills = job.skills.map(s => s.toLowerCase());
    const commonSkills = userSkills.filter(skill => 
      jobSkills.some(jobSkill => jobSkill.includes(skill) || skill.includes(jobSkill))
    );
    
    return Math.min(95, Math.max(30, (commonSkills.length / Math.max(jobSkills.length, 1)) * 100));
  }
}

export async function extractSkillsFromText(text: string): Promise<string[]> {
  try {
    const prompt = `
      Analyze the following text (resume, bio, or job description) and extract relevant professional skills.
      Focus on:
      1. Programming languages
      2. Frameworks and libraries
      3. Tools and software
      4. Professional competencies
      5. Industry-specific skills
      6. Certifications mentioned
      
      Text to analyze:
      ${text}
      
      Return a JSON object with:
      - skills: array of extracted skills (max 20, most relevant first)
      - categories: object grouping skills by type (technical, soft, tools, etc.)
      
      Only extract skills that are clearly mentioned or strongly implied.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert at identifying and extracting professional skills from text. Be precise and avoid hallucinating skills that aren't clearly present."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.skills || [];

  } catch (error) {
    console.error('Skill extraction error:', error);
    
    // Fallback: basic keyword extraction
    const commonSkills = [
      'JavaScript', 'Python', 'Java', 'React', 'Node.js', 'TypeScript', 'HTML', 'CSS',
      'SQL', 'MongoDB', 'PostgreSQL', 'AWS', 'Docker', 'Git', 'REST API', 'GraphQL',
      'Machine Learning', 'Data Analysis', 'Project Management', 'Agile', 'Scrum',
      'Leadership', 'Communication', 'Problem Solving', 'Team Collaboration'
    ];
    
    const extractedSkills = commonSkills.filter(skill => 
      text.toLowerCase().includes(skill.toLowerCase())
    );
    
    return extractedSkills.slice(0, 10);
  }
}

export async function generateJobRecommendations(user: User, allJobs: Job[]): Promise<Job[]> {
  try {
    if (allJobs.length === 0) return [];

    const userProfile = `
      Skills: ${user.skills.join(', ')}
      Bio: ${user.bio || ''}
      Location: ${user.location || ''}
    `;

    const jobSummaries = allJobs.slice(0, 20).map(job => ({
      id: job.id,
      title: job.title,
      company: job.company,
      skills: job.skills.join(', '),
      location: job.location,
      remote: job.remote
    }));

    const prompt = `
      You are an AI job recommendation engine. Given a user profile and available jobs, recommend the best matches.
      
      User Profile:
      ${userProfile}
      
      Available Jobs:
      ${JSON.stringify(jobSummaries, null, 2)}
      
      Analyze and return JSON with:
      - recommendedJobIds: array of job IDs ordered by relevance (max 5)
      - reasoning: object with jobId as key and explanation as value
      
      Consider skill match, location preference, and career progression.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert career advisor that provides personalized job recommendations."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    const recommendedIds = result.recommendedJobIds || [];
    
    return allJobs.filter(job => recommendedIds.includes(job.id));

  } catch (error) {
    console.error('Job recommendation error:', error);
    
    // Fallback: simple skill-based filtering
    const userSkills = user.skills.map(s => s.toLowerCase());
    return allJobs
      .filter(job => {
        const jobSkills = job.skills.map(s => s.toLowerCase());
        return jobSkills.some(skill => 
          userSkills.some(userSkill => 
            skill.includes(userSkill) || userSkill.includes(skill)
          )
        );
      })
      .slice(0, 5);
  }
}
