import { 
  users, jobs, posts, applications, connections, notifications,
  type User, type InsertUser, type Job, type InsertJob,
  type Post, type InsertPost, type Application, type InsertApplication,
  type Connection, type InsertConnection, type Notification, type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, ilike, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User>;
  
  // Job methods
  getJob(id: string): Promise<Job | undefined>;
  getJobs(limit?: number, offset?: number, filters?: any): Promise<Job[]>;
  getJobsByUser(userId: string): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: string, updates: Partial<InsertJob>): Promise<Job>;
  deleteJob(id: string): Promise<void>;
  searchJobs(query: string, skills?: string[]): Promise<Job[]>;
  
  // Post methods
  getPost(id: string): Promise<Post | undefined>;
  getPosts(limit?: number, offset?: number): Promise<Post[]>;
  getPostsByUser(userId: string): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, updates: Partial<InsertPost>): Promise<Post>;
  deletePost(id: string): Promise<void>;
  
  // Application methods
  getApplication(id: string): Promise<Application | undefined>;
  getApplicationsByJob(jobId: string): Promise<Application[]>;
  getApplicationsByUser(userId: string): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplication(id: string, updates: Partial<InsertApplication>): Promise<Application>;
  
  // Connection methods
  getConnection(requesterId: string, addresseeId: string): Promise<Connection | undefined>;
  getConnectionsByUser(userId: string): Promise<Connection[]>;
  createConnection(connection: InsertConnection): Promise<Connection>;
  updateConnection(id: string, updates: Partial<InsertConnection>): Promise<Connection>;
  
  // Notification methods
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Job methods
  async getJob(id: string): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job || undefined;
  }

  async getJobs(limit = 50, offset = 0, filters: any = {}): Promise<Job[]> {
    let query = db.select().from(jobs).where(eq(jobs.isActive, true));
    
    if (filters.skills && filters.skills.length > 0) {
      query = query.where(sql`${jobs.skills} && ${filters.skills}`);
    }
    
    if (filters.location) {
      query = query.where(ilike(jobs.location, `%${filters.location}%`));
    }
    
    if (filters.remote !== undefined) {
      query = query.where(eq(jobs.remote, filters.remote));
    }
    
    return query
      .orderBy(desc(jobs.isFeatured), desc(jobs.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getJobsByUser(userId: string): Promise<Job[]> {
    return db.select().from(jobs)
      .where(eq(jobs.postedBy, userId))
      .orderBy(desc(jobs.createdAt));
  }

  async createJob(job: InsertJob): Promise<Job> {
    const [newJob] = await db
      .insert(jobs)
      .values({
        ...job,
        updatedAt: new Date(),
      })
      .returning();
    return newJob;
  }

  async updateJob(id: string, updates: Partial<InsertJob>): Promise<Job> {
    const [job] = await db
      .update(jobs)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(jobs.id, id))
      .returning();
    return job;
  }

  async deleteJob(id: string): Promise<void> {
    await db.delete(jobs).where(eq(jobs.id, id));
  }

  async searchJobs(query: string, skills: string[] = []): Promise<Job[]> {
    let dbQuery = db.select().from(jobs)
      .where(
        and(
          eq(jobs.isActive, true),
          or(
            ilike(jobs.title, `%${query}%`),
            ilike(jobs.description, `%${query}%`),
            ilike(jobs.company, `%${query}%`)
          )
        )
      );
    
    if (skills.length > 0) {
      dbQuery = dbQuery.where(sql`${jobs.skills} && ${skills}`);
    }
    
    return dbQuery.orderBy(desc(jobs.isFeatured), desc(jobs.createdAt));
  }

  // Post methods
  async getPost(id: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post || undefined;
  }

  async getPosts(limit = 50, offset = 0): Promise<Post[]> {
    return db.select().from(posts)
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getPostsByUser(userId: string): Promise<Post[]> {
    return db.select().from(posts)
      .where(eq(posts.authorId, userId))
      .orderBy(desc(posts.createdAt));
  }

  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db
      .insert(posts)
      .values({
        ...post,
        updatedAt: new Date(),
      })
      .returning();
    return newPost;
  }

  async updatePost(id: string, updates: Partial<InsertPost>): Promise<Post> {
    const [post] = await db
      .update(posts)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(posts.id, id))
      .returning();
    return post;
  }

  async deletePost(id: string): Promise<void> {
    await db.delete(posts).where(eq(posts.id, id));
  }

  // Application methods
  async getApplication(id: string): Promise<Application | undefined> {
    const [application] = await db.select().from(applications).where(eq(applications.id, id));
    return application || undefined;
  }

  async getApplicationsByJob(jobId: string): Promise<Application[]> {
    return db.select().from(applications)
      .where(eq(applications.jobId, jobId))
      .orderBy(desc(applications.createdAt));
  }

  async getApplicationsByUser(userId: string): Promise<Application[]> {
    return db.select().from(applications)
      .where(eq(applications.applicantId, userId))
      .orderBy(desc(applications.createdAt));
  }

  async createApplication(application: InsertApplication): Promise<Application> {
    const [newApplication] = await db
      .insert(applications)
      .values({
        ...application,
        updatedAt: new Date(),
      })
      .returning();
    return newApplication;
  }

  async updateApplication(id: string, updates: Partial<InsertApplication>): Promise<Application> {
    const [application] = await db
      .update(applications)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(applications.id, id))
      .returning();
    return application;
  }

  // Connection methods
  async getConnection(requesterId: string, addresseeId: string): Promise<Connection | undefined> {
    const [connection] = await db.select().from(connections)
      .where(
        or(
          and(eq(connections.requesterId, requesterId), eq(connections.addresseeId, addresseeId)),
          and(eq(connections.requesterId, addresseeId), eq(connections.addresseeId, requesterId))
        )
      );
    return connection || undefined;
  }

  async getConnectionsByUser(userId: string): Promise<Connection[]> {
    return db.select().from(connections)
      .where(
        and(
          or(eq(connections.requesterId, userId), eq(connections.addresseeId, userId)),
          eq(connections.status, "accepted")
        )
      )
      .orderBy(desc(connections.createdAt));
  }

  async createConnection(connection: InsertConnection): Promise<Connection> {
    const [newConnection] = await db
      .insert(connections)
      .values({
        ...connection,
        updatedAt: new Date(),
      })
      .returning();
    return newConnection;
  }

  async updateConnection(id: string, updates: Partial<InsertConnection>): Promise<Connection> {
    const [connection] = await db
      .update(connections)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(connections.id, id))
      .returning();
    return connection;
  }

  // Notification methods
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }

  async markNotificationAsRead(id: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }
}

export const storage = new DatabaseStorage();
