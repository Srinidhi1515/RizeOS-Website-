export interface User {
  id: string;
  username: string;
  email: string;
  name: string;
  bio?: string;
  location?: string;
  linkedinUrl?: string;
  profileImage?: string;
  walletAddress?: string;
  skills: string[];
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Job {
  id: string;
  title: string;
  description: string;
  company: string;
  location?: string;
  salaryMin?: number;
  salaryMax?: number;
  currency: string;
  jobType: string;
  remote: boolean;
  skills: string[];
  requirements?: string;
  benefits?: string;
  applicationFee?: string;
  feeToken?: string;
  companyLogo?: string;
  isActive: boolean;
  isFeatured: boolean;
  postedBy?: string;
  paymentTxHash?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Post {
  id: string;
  content: string;
  images: string[];
  authorId?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: string;
  updatedAt: string;
}

export interface Application {
  id: string;
  jobId?: string;
  applicantId?: string;
  coverLetter?: string;
  resume?: string;
  status: string;
  matchScore?: number;
  paymentTxHash?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  userId?: string;
  type: string;
  title: string;
  message: string;
  data?: any;
  isRead: boolean;
  createdAt: string;
}

export interface WalletState {
  isConnected: boolean;
  address: string | null;
  balance: string | null;
  network: string | null;
  provider: any;
}

export interface JobFilters {
  skills?: string[];
  location?: string;
  remote?: boolean;
  search?: string;
  jobType?: string;
}

export interface MatchScore {
  score: number;
  reasons: string[];
}
