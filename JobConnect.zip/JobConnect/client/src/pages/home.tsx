import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/navbar";
import ProfileSidebar from "@/components/profile-sidebar";
import JobCard from "@/components/job-card";
import PostCreation from "@/components/post-creation";
import AIRecommendations from "@/components/ai-recommendations";
import { Job, Post } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, Star } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user, isLoading } = useAuth();

  const { data: jobs = [], isLoading: jobsLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
    enabled: !!user,
  });

  const { data: posts = [], isLoading: postsLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Welcome to JobConnect</h1>
            <p className="text-gray-600 mb-6">
              Professional networking and Web3 job portal
            </p>
            <div className="space-y-2">
              <Link href="/login">
                <Button className="w-full">Sign In</Button>
              </Link>
              <Link href="/register">
                <Button variant="outline" className="w-full">Create Account</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const featuredJobs = jobs.filter(job => job.isFeatured).slice(0, 2);
  const regularJobs = jobs.filter(job => !job.isFeatured).slice(0, 3);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Navbar />
      
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Welcome back, {user.name}</h1>
            <p className="text-xl text-blue-100 mb-8">Your professional network awaits</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h3 className="text-lg font-semibold mb-2">Network</h3>
                <p className="text-blue-100">Connect with industry professionals</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h3 className="text-lg font-semibold mb-2">Opportunities</h3>
                <p className="text-blue-100">Discover your next career move</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h3 className="text-lg font-semibold mb-2">Growth</h3>
                <p className="text-blue-100">Advance your professional journey</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          {/* Left Sidebar - Profile */}
          <div className="xl:col-span-3">
            <div className="sticky top-8">
              <ProfileSidebar user={user} />
            </div>
          </div>

          {/* Main Content */}
          <div className="xl:col-span-6">
            <div className="space-y-6">
              <PostCreation />
              
              {/* Featured Jobs Section */}
              {featuredJobs.length > 0 && (
                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-xl p-6 border border-indigo-100 dark:border-indigo-800">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center">
                      <Star className="w-5 h-5 mr-2 text-yellow-500" />
                      Featured Opportunities
                    </h2>
                    <Link href="/jobs">
                      <Button variant="outline" size="sm">View All</Button>
                    </Link>
                  </div>
                  <div className="space-y-4">
                    {featuredJobs.map((job) => (
                      <div key={job.id} className="relative">
                        <JobCard job={job} showMatchScore />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Professional Feed */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Professional Updates</h2>
                </div>
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {posts.map((post) => (
                    <div key={post.id} className="p-6">
                      <div className="flex items-start space-x-4">
                        <Avatar className="w-12 h-12 ring-2 ring-gray-200 dark:ring-gray-600">
                          <AvatarImage src="/api/placeholder/48/48" />
                          <AvatarFallback className="bg-indigo-100 text-indigo-700 font-semibold">
                            {user.name?.split(' ').map(n => n[0]).join('') || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="font-semibold text-gray-900 dark:text-white">{user.name}</h4>
                            <span className="text-gray-500 text-sm">•</span>
                            <span className="text-gray-500 text-sm">{new Date(post.createdAt).toLocaleDateString()}</span>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">Professional</p>
                          
                          <p className="text-gray-800 dark:text-gray-200 leading-relaxed whitespace-pre-line mb-4">
                            {post.content}
                          </p>
                          
                          <div className="flex items-center space-x-6 text-sm border-t border-gray-100 dark:border-gray-600 pt-4">
                            <button className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                              <Heart className="w-4 h-4" />
                              <span>{post.likes}</span>
                            </button>
                            <button className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                              <MessageCircle className="w-4 h-4" />
                              <span>{post.comments}</span>
                            </button>
                            <button className="flex items-center space-x-2 text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                              <Share2 className="w-4 h-4" />
                              <span>Share</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Jobs */}
              {regularJobs.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
                  <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">Recent Opportunities</h2>
                  </div>
                  <div className="p-6 space-y-4">
                    {regularJobs.map((job) => (
                      <JobCard key={job.id} job={job} showMatchScore />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar - AI Recommendations */}
          <div className="xl:col-span-3">
            <div className="sticky top-8">
              <AIRecommendations />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
