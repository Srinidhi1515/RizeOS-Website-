import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, MapPin, Briefcase, MessageCircle, UserPlus, Search } from "lucide-react";
import { useState } from "react";

interface NetworkUser {
  id: string;
  name: string;
  bio: string;
  location: string;
  skills: string[];
  profileImage: string;
  isVerified: boolean;
  connectionStatus: 'connected' | 'pending' | 'none';
  mutualConnections: number;
}

export default function Network() {
  const { user, isLoading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Sample network data - in a real app, this would come from the API
  const networkUsers: NetworkUser[] = [
    {
      id: '1',
      name: 'Sarah Chen',
      bio: 'Senior Software Engineer at Google with 8 years of experience in distributed systems and cloud architecture.',
      location: 'Mountain View, CA',
      skills: ['Java', 'Python', 'Kubernetes', 'GCP', 'Microservices'],
      profileImage: '/api/placeholder/64/64',
      isVerified: true,
      connectionStatus: 'connected',
      mutualConnections: 12
    },
    {
      id: '2',
      name: 'Marcus Rodriguez',
      bio: 'Product Manager at Stripe focusing on payment infrastructure and financial technology.',
      location: 'San Francisco, CA',
      skills: ['Product Strategy', 'Fintech', 'Analytics', 'Leadership'],
      profileImage: '/api/placeholder/64/64',
      isVerified: true,
      connectionStatus: 'connected',
      mutualConnections: 8
    },
    {
      id: '3',
      name: 'Elena Volkov',
      bio: 'AI Research Scientist at OpenAI working on large language models and natural language processing.',
      location: 'San Francisco, CA',
      skills: ['Machine Learning', 'NLP', 'Python', 'Research', 'Deep Learning'],
      profileImage: '/api/placeholder/64/64',
      isVerified: true,
      connectionStatus: 'connected',
      mutualConnections: 15
    },
    {
      id: '4',
      name: 'James Thompson',
      bio: 'Blockchain developer and DeFi protocol architect. Building the future of decentralized finance.',
      location: 'Remote',
      skills: ['Solidity', 'DeFi', 'Smart Contracts', 'Web3', 'Ethereum'],
      profileImage: '/api/placeholder/64/64',
      isVerified: true,
      connectionStatus: 'pending',
      mutualConnections: 5
    },
    {
      id: '5',
      name: 'Priya Patel',
      bio: 'Senior UX Designer at Airbnb creating delightful travel experiences for global products.',
      location: 'San Francisco, CA',
      skills: ['UX Design', 'User Research', 'Figma', 'Design Systems', 'Prototyping'],
      profileImage: '/api/placeholder/64/64',
      isVerified: true,
      connectionStatus: 'connected',
      mutualConnections: 9
    }
  ];

  const filteredUsers = networkUsers.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.bio.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">My Network</h1>
          <p className="text-gray-600 dark:text-gray-400">Connect with professionals in your industry</p>
        </div>

        {/* Search and Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            {/* Search Bar */}
            <div className="relative mb-6">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <Input
                className="pl-10"
                placeholder="Search connections by name, skills, or company..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Connections Grid */}
            <div className="space-y-4">
              {filteredUsers.map((networkUser) => (
                <Card key={networkUser.id} className="shadow-sm border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Avatar className="w-16 h-16 ring-2 ring-gray-200 dark:ring-gray-600">
                        <AvatarImage src={networkUser.profileImage} />
                        <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold text-lg">
                          {networkUser.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                            {networkUser.name}
                          </h3>
                          {networkUser.isVerified && (
                            <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                              Verified
                            </Badge>
                          )}
                          {networkUser.connectionStatus === 'connected' && (
                            <Badge variant="outline" className="text-xs border-green-200 text-green-700 dark:border-green-800 dark:text-green-300">
                              Connected
                            </Badge>
                          )}
                          {networkUser.connectionStatus === 'pending' && (
                            <Badge variant="outline" className="text-xs border-yellow-200 text-yellow-700 dark:border-yellow-800 dark:text-yellow-300">
                              Pending
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 leading-relaxed">
                          {networkUser.bio}
                        </p>
                        
                        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3">
                          <MapPin className="w-4 h-4 mr-1" />
                          {networkUser.location}
                          {networkUser.connectionStatus === 'connected' && (
                            <>
                              <span className="mx-2">•</span>
                              <Users className="w-4 h-4 mr-1" />
                              {networkUser.mutualConnections} mutual connections
                            </>
                          )}
                        </div>
                        
                        <div className="flex flex-wrap gap-1 mb-4">
                          {networkUser.skills.slice(0, 4).map((skill) => (
                            <Badge key={skill} variant="secondary" className="text-xs bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300">
                              {skill}
                            </Badge>
                          ))}
                          {networkUser.skills.length > 4 && (
                            <Badge variant="outline" className="text-xs">
                              +{networkUser.skills.length - 4} more
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex flex-col space-y-2">
                        {networkUser.connectionStatus === 'connected' ? (
                          <Button size="sm" variant="outline" className="flex items-center space-x-2">
                            <MessageCircle className="w-4 h-4" />
                            <span>Message</span>
                          </Button>
                        ) : networkUser.connectionStatus === 'pending' ? (
                          <Button size="sm" variant="outline" disabled>
                            <span>Pending</span>
                          </Button>
                        ) : (
                          <Button size="sm" className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700">
                            <UserPlus className="w-4 h-4" />
                            <span>Connect</span>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              {/* Network Stats */}
              <Card className="shadow-sm border-gray-200 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">Network Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Total Connections</span>
                    <span className="font-bold text-indigo-600 dark:text-indigo-400">847</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400">New This Week</span>
                    <span className="font-bold text-green-600 dark:text-green-400">+12</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Pending Requests</span>
                    <span className="font-bold text-yellow-600 dark:text-yellow-400">3</span>
                  </div>
                </CardContent>
              </Card>

              {/* Suggested Connections */}
              <Card className="shadow-sm border-gray-200 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">People You May Know</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center p-4 text-gray-500 dark:text-gray-400">
                    <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">AI-powered suggestions coming soon!</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}