import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { WalletState } from "@/types";
import { useToast } from "@/hooks/use-toast";

interface Web3ContextType {
  wallet: WalletState;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  sendPayment: (to: string, amount: string, token: string) => Promise<string>;
  isConnecting: boolean;
}

const Web3Context = createContext<Web3ContextType | undefined>(undefined);

export function Web3Provider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>({
    isConnected: false,
    address: null,
    balance: null,
    network: null,
    provider: null,
  });
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkWalletConnection();
  }, []);

  const checkWalletConnection = async () => {
    try {
      if (typeof window !== 'undefined' && window.ethereum) {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          await connectMetaMask();
        }
      }
    } catch (error) {
      console.error('Error checking wallet connection:', error);
    }
  };

  const connectMetaMask = async () => {
    try {
      if (!window.ethereum) {
        toast({
          title: "MetaMask not found",
          description: "Please install MetaMask to continue",
          variant: "destructive",
        });
        return;
      }

      const accounts = await window.ethereum.request({ 
        method: 'eth_requestAccounts' 
      });
      
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      const balance = await window.ethereum.request({
        method: 'eth_getBalance',
        params: [accounts[0], 'latest']
      });

      // Convert balance from wei to ether
      const balanceInEth = (parseInt(balance, 16) / Math.pow(10, 18)).toFixed(4);

      setWallet({
        isConnected: true,
        address: accounts[0],
        balance: `${balanceInEth} ETH`,
        network: getNetworkName(chainId),
        provider: window.ethereum,
      });

      toast({
        title: "Wallet connected",
        description: `Connected to ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`,
      });
    } catch (error) {
      console.error('Error connecting to MetaMask:', error);
      toast({
        title: "Connection failed",
        description: "Failed to connect to MetaMask",
        variant: "destructive",
      });
    }
  };

  const connectPhantom = async () => {
    try {
      if (!window.solana) {
        toast({
          title: "Phantom not found",
          description: "Please install Phantom wallet to continue",
          variant: "destructive",
        });
        return;
      }

      const response = await window.solana.connect();
      
      // Get SOL balance (simplified)
      const balance = "0.0000 SOL"; // In production, fetch actual balance

      setWallet({
        isConnected: true,
        address: response.publicKey.toString(),
        balance,
        network: "Solana",
        provider: window.solana,
      });

      toast({
        title: "Wallet connected",
        description: `Connected to Phantom wallet`,
      });
    } catch (error) {
      console.error('Error connecting to Phantom:', error);
      toast({
        title: "Connection failed",
        description: "Failed to connect to Phantom",
        variant: "destructive",
      });
    }
  };

  const connectWallet = async () => {
    setIsConnecting(true);
    try {
      // Try MetaMask first, then Phantom
      if (window.ethereum) {
        await connectMetaMask();
      } else if (window.solana) {
        await connectPhantom();
      } else {
        toast({
          title: "No wallet found",
          description: "Please install MetaMask or Phantom wallet",
          variant: "destructive",
        });
      }
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setWallet({
      isConnected: false,
      address: null,
      balance: null,
      network: null,
      provider: null,
    });
    
    toast({
      title: "Wallet disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  const sendPayment = async (to: string, amount: string, token: string): Promise<string> => {
    if (!wallet.isConnected || !wallet.provider) {
      throw new Error('Wallet not connected');
    }

    try {
      if (token === 'SOL' && window.solana) {
        // Solana payment logic
        const { PublicKey, Transaction, SystemProgram } = await import('@solana/web3.js');
        
        // This is simplified - in production, you'd need proper Solana connection
        const transaction = new Transaction().add(
          SystemProgram.transfer({
            fromPubkey: new PublicKey(wallet.address!),
            toPubkey: new PublicKey(to),
            lamports: parseFloat(amount) * 1000000000, // Convert SOL to lamports
          })
        );

        const signature = await window.solana.signAndSendTransaction(transaction);
        return signature.signature;
      } else {
        // Ethereum payment logic
        const params = [{
          from: wallet.address,
          to: to,
          value: (parseFloat(amount) * Math.pow(10, 18)).toString(16), // Convert to wei
        }];

        const txHash = await wallet.provider.request({
          method: 'eth_sendTransaction',
          params,
        });

        return txHash;
      }
    } catch (error) {
      console.error('Payment error:', error);
      throw error;
    }
  };

  const getNetworkName = (chainId: string): string => {
    const networks: { [key: string]: string } = {
      '0x1': 'Ethereum Mainnet',
      '0x89': 'Polygon Mainnet',
      '0x5': 'Goerli Testnet',
      '0x13881': 'Mumbai Testnet',
    };
    return networks[chainId] || 'Unknown Network';
  };

  return (
    <Web3Context.Provider value={{
      wallet,
      connectWallet,
      disconnectWallet,
      sendPayment,
      isConnecting,
    }}>
      {children}
    </Web3Context.Provider>
  );
}

export function useWeb3() {
  const context = useContext(Web3Context);
  if (context === undefined) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
}

// Extend window interface for TypeScript
declare global {
  interface Window {
    ethereum?: any;
    solana?: any;
  }
}
