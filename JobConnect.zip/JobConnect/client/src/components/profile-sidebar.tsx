import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { User } from "@/types";
import { Plus, Bot, Upload, MapPin, Users, Eye } from "lucide-react";

interface ProfileSidebarProps {
  user: User;
}

export default function ProfileSidebar({ user }: ProfileSidebarProps) {
  // Calculate profile completion
  const completionScore = (() => {
    let score = 0;
    if (user.name) score += 20;
    if (user.bio) score += 20;
    if (user.location) score += 15;
    if (user.skills.length > 0) score += 20;
    if (user.linkedinUrl) score += 10;
    if (user.walletAddress) score += 15;
    return score;
  })();

  return (
    <div className="space-y-6">
      {/* Main Profile Card */}
      <Card className="overflow-hidden shadow-lg border-gray-200 dark:border-gray-700">
        {/* Cover Image */}
        <div className="h-24 bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 relative">
          <div className="absolute inset-0 bg-black/20"></div>
        </div>
        
        {/* Profile Content */}
        <CardContent className="relative pt-0 pb-6 px-6">
          <div className="absolute -top-8 left-6">
            <Avatar className="w-20 h-20 border-4 border-white dark:border-gray-800 shadow-lg">
              <AvatarImage src={user.profileImage} />
              <AvatarFallback className="text-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold">
                {user.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
          </div>
          
          <div className="pt-10">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">{user.name}</h3>
            {user.isVerified && (
              <div className="flex items-center mt-1">
                <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300">
                  Verified Professional
                </Badge>
              </div>
            )}
            {user.bio && (
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 leading-relaxed">{user.bio}</p>
            )}
            {user.location && (
              <p className="text-sm text-gray-500 dark:text-gray-500 mt-2 flex items-center">
                <MapPin className="w-4 h-4 mr-1" />
                {user.location}
              </p>
            )}
          </div>
        </CardContent>
        
        {/* Stats */}
        <div className="border-t border-gray-200 dark:border-gray-700 px-6 py-4 bg-gray-50 dark:bg-gray-800/50">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">127</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Profile Views</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">847</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Connections</div>
            </div>
          </div>
        </div>
        
        {/* AI Match Score */}
        <div className="border-t border-gray-200 dark:border-gray-700 px-6 py-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-gray-900 dark:text-white">AI Match Score</h4>
            <Badge variant="outline" className="text-xs border-green-200 text-green-700 dark:border-green-800 dark:text-green-300">
              Excellent
            </Badge>
          </div>
          <div className="flex items-center space-x-3">
            <Progress value={85} className="flex-1" />
            <span className="text-sm font-bold text-green-600 dark:text-green-400">85%</span>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Based on your skills and recent activity</p>
        </div>
      </Card>

      {/* Profile Completion */}
      <Card className="shadow-sm border-gray-200 dark:border-gray-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900 dark:text-white">Profile Strength</h4>
            <Badge variant={completionScore >= 80 ? "default" : "secondary"} className="text-xs">
              {completionScore >= 80 ? "Strong" : "Good"}
            </Badge>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Completion</span>
              <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{completionScore}%</span>
            </div>
            <Progress value={completionScore} className="h-2" />
            
            {completionScore < 100 && (
              <div className="space-y-2 mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-xs font-medium text-gray-700 dark:text-gray-300">Boost your visibility:</p>
                <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                  {!user.bio && <li>• Add a professional summary</li>}
                  {!user.location && <li>• Add your location</li>}
                  {user.skills.length === 0 && <li>• List your skills</li>}
                  {!user.linkedinUrl && <li>• Connect LinkedIn profile</li>}
                  {!user.walletAddress && <li>• Connect Web3 wallet</li>}
                </ul>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Skills Preview */}
      {user.skills.length > 0 && (
        <Card className="shadow-sm border-gray-200 dark:border-gray-700">
          <CardContent className="p-6">
            <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Top Skills</h4>
            <div className="flex flex-wrap gap-2">
              {user.skills.slice(0, 6).map((skill) => (
                <Badge key={skill} variant="secondary" className="text-xs bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300 hover:bg-indigo-200 dark:hover:bg-indigo-800 transition-colors">
                  {skill}
                </Badge>
              ))}
              {user.skills.length > 6 && (
                <Badge variant="outline" className="text-xs border-indigo-200 text-indigo-600 dark:border-indigo-700 dark:text-indigo-400">
                  +{user.skills.length - 6} more
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card className="shadow-sm border-gray-200 dark:border-gray-700">
        <CardContent className="p-6">
          <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h4>
          <div className="space-y-2">
            <Button variant="ghost" className="w-full justify-start h-auto p-4 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 border border-indigo-200 dark:border-indigo-800 hover:from-indigo-100 hover:to-purple-100 dark:hover:from-indigo-900/30 dark:hover:to-purple-900/30 transition-all">
              <Plus className="w-5 h-5 mr-3 text-indigo-600 dark:text-indigo-400" />
              <div className="text-left">
                <div className="text-sm font-medium text-gray-900 dark:text-white">Post a Job</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">Share opportunities with the network</div>
              </div>
            </Button>
            <Button variant="ghost" className="w-full justify-start h-auto p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-800 hover:from-purple-100 hover:to-pink-100 dark:hover:from-purple-900/30 dark:hover:to-pink-900/30 transition-all">
              <Bot className="w-5 h-5 mr-3 text-purple-600 dark:text-purple-400" />
              <div className="text-left">
                <div className="text-sm font-medium text-gray-900 dark:text-white">AI Job Match</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">Find perfect opportunities with AI</div>
              </div>
            </Button>
            <Button variant="ghost" className="w-full justify-start h-auto p-4 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border border-blue-200 dark:border-blue-800 hover:from-blue-100 hover:to-cyan-100 dark:hover:from-blue-900/30 dark:hover:to-cyan-900/30 transition-all">
              <Upload className="w-5 h-5 mr-3 text-blue-600 dark:text-blue-400" />
              <div className="text-left">
                <div className="text-sm font-medium text-gray-900 dark:text-white">Upload Resume</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">Let AI extract your skills</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
