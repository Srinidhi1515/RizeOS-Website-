import { useState } from "react";
import { useWeb3 } from "@/hooks/use-web3";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Job } from "@/types";
import { 
  Wallet, 
  Coins, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  ExternalLink,
  Shield
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: Job;
  onPaymentSuccess: (txHash: string) => void;
}

enum PaymentStep {
  REVIEW = 'review',
  PROCESSING = 'processing',
  SUCCESS = 'success',
  ERROR = 'error'
}

export default function PaymentModal({ 
  isOpen, 
  onClose, 
  job, 
  onPaymentSuccess 
}: PaymentModalProps) {
  const { wallet, sendPayment, connectWallet } = useWeb3();
  const { toast } = useToast();
  const [step, setStep] = useState<PaymentStep>(PaymentStep.REVIEW);
  const [txHash, setTxHash] = useState<string>("");
  const [error, setError] = useState<string>("");

  const adminWallet = {
    'ETH': '0x742D35Cc6634C0532925a3b8D33AA6a23CCbF3f8',
    'MATIC': '0x742D35Cc6634C0532925a3b8D33AA6a23CCbF3f8', 
    'SOL': '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM'
  };

  const estimatedGasFee = {
    'ETH': '0.002',
    'MATIC': '0.01',
    'SOL': '0.001'
  };

  const handlePayment = async () => {
    if (!wallet.isConnected) {
      await connectWallet();
      return;
    }

    if (!job.applicationFee || !job.feeToken) {
      toast({
        title: "Payment Error",
        description: "Invalid payment configuration",
        variant: "destructive"
      });
      return;
    }

    setStep(PaymentStep.PROCESSING);
    setError("");

    try {
      const toAddress = adminWallet[job.feeToken as keyof typeof adminWallet];
      const txHash = await sendPayment(toAddress, job.applicationFee, job.feeToken);
      
      setTxHash(txHash);
      setStep(PaymentStep.SUCCESS);
      
      // Simulate blockchain confirmation delay
      setTimeout(() => {
        onPaymentSuccess(txHash);
        toast({
          title: "Payment Successful",
          description: "Your job application has been submitted",
        });
      }, 2000);

    } catch (error: any) {
      console.error('Payment failed:', error);
      setError(error.message || 'Payment failed. Please try again.');
      setStep(PaymentStep.ERROR);
      
      toast({
        title: "Payment Failed",
        description: error.message || "Transaction was rejected or failed",
        variant: "destructive"
      });
    }
  };

  const handleClose = () => {
    if (step === PaymentStep.PROCESSING) return; // Prevent closing during payment
    setStep(PaymentStep.REVIEW);
    setError("");
    setTxHash("");
    onClose();
  };

  const getStepProgress = () => {
    switch (step) {
      case PaymentStep.REVIEW: return 25;
      case PaymentStep.PROCESSING: return 75;
      case PaymentStep.SUCCESS: return 100;
      case PaymentStep.ERROR: return 50;
      default: return 0;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Coins className="w-5 h-5 text-indigo-600" />
            <span>Web3 Payment Required</span>
          </DialogTitle>
          <DialogDescription>
            Pay platform fee to verify and publish your job application
          </DialogDescription>
        </DialogHeader>

        {/* Progress Indicator */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Payment Progress</span>
            <span>{getStepProgress()}%</span>
          </div>
          <Progress value={getStepProgress()} className="h-2" />
        </div>

        {/* Review Step */}
        {step === PaymentStep.REVIEW && (
          <div className="space-y-6">
            {/* Job Info */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">{job.title}</h4>
              <p className="text-sm text-gray-600">{job.company}</p>
            </div>

            {/* Payment Breakdown */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Application Fee</span>
                <div className="flex items-center space-x-1">
                  <Coins className="w-4 h-4 text-indigo-600" />
                  <span className="font-medium">{job.applicationFee} {job.feeToken}</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Network Fee (est.)</span>
                <span className="font-medium">
                  ~{estimatedGasFee[job.feeToken as keyof typeof estimatedGasFee]} {job.feeToken}
                </span>
              </div>
              
              <Separator />
              
              <div className="flex justify-between items-center font-medium">
                <span>Total</span>
                <span>
                  {parseFloat(job.applicationFee) + parseFloat(estimatedGasFee[job.feeToken as keyof typeof estimatedGasFee])} {job.feeToken}
                </span>
              </div>
            </div>

            {/* Wallet Status */}
            {wallet.isConnected ? (
              <div className="bg-green-50 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium text-green-800">Wallet Connected</span>
                </div>
                <p className="text-xs text-green-700 mt-1">
                  {wallet.address?.slice(0, 10)}...{wallet.address?.slice(-8)}
                </p>
                <p className="text-xs text-green-700">Balance: {wallet.balance}</p>
              </div>
            ) : (
              <div className="bg-yellow-50 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600" />
                  <span className="text-sm font-medium text-yellow-800">Wallet Required</span>
                </div>
                <p className="text-xs text-yellow-700 mt-1">
                  Connect your wallet to proceed with payment
                </p>
              </div>
            )}

            {/* Security Notice */}
            <div className="bg-blue-50 rounded-lg p-3">
              <div className="flex items-start space-x-2">
                <Shield className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div className="text-xs text-blue-800">
                  <p className="font-medium">Secure Payment</p>
                  <p>Transaction will be processed securely on the blockchain</p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <Button variant="outline" onClick={handleClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handlePayment}
                className="flex-1 bg-indigo-600 hover:bg-indigo-700"
              >
                <Wallet className="w-4 h-4 mr-2" />
                Pay Now
              </Button>
            </div>
          </div>
        )}

        {/* Processing Step */}
        {step === PaymentStep.PROCESSING && (
          <div className="text-center space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Processing Payment</h4>
              <p className="text-sm text-gray-600">
                Please confirm the transaction in your wallet and wait for blockchain confirmation
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Waiting for wallet confirmation...</span>
              </div>
            </div>
          </div>
        )}

        {/* Success Step */}
        {step === PaymentStep.SUCCESS && (
          <div className="text-center space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Payment Successful!</h4>
              <p className="text-sm text-gray-600">
                Your application has been submitted and is being processed
              </p>
            </div>

            {txHash && (
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-600 mb-1">Transaction Hash:</p>
                <div className="flex items-center justify-between">
                  <code className="text-xs font-mono text-gray-800 break-all">
                    {txHash}
                  </code>
                  <Button variant="ghost" size="sm">
                    <ExternalLink className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            )}

            <Button onClick={handleClose} className="w-full">
              Continue
            </Button>
          </div>
        )}

        {/* Error Step */}
        {step === PaymentStep.ERROR && (
          <div className="text-center space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Payment Failed</h4>
              <p className="text-sm text-gray-600 mb-2">{error}</p>
              <p className="text-xs text-gray-500">
                Please check your wallet balance and try again
              </p>
            </div>

            <div className="flex space-x-3">
              <Button variant="outline" onClick={handleClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={() => setStep(PaymentStep.REVIEW)}
                className="flex-1"
              >
                Try Again
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
