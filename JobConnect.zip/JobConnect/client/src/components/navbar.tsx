import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useWeb3 } from "@/hooks/use-web3";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Network, Search, Home, Briefcase, Users, Bell, Wallet, User, LogOut } from "lucide-react";
import { Notification } from "@/types";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { wallet, connectWallet } = useWeb3();
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/jobs", icon: Briefcase, label: "Jobs" },
    { href: "/network", icon: Users, label: "Network" },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Navigate to jobs page with search query
      window.location.href = `/jobs?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <nav className="bg-white dark:bg-gray-900 shadow-lg border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Search */}
          <div className="flex items-center flex-1">
            <Link href="/">
              <div className="flex-shrink-0 flex items-center cursor-pointer">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg mr-3">
                  <Network className="h-6 w-6 text-white" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-bold text-gray-900 dark:text-white">JobConnect</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400 -mt-1">Professional Network</span>
                </div>
              </div>
            </Link>
            
            {/* Search Bar */}
            <div className="max-w-lg w-full lg:max-w-md ml-8 hidden md:block">
              <form onSubmit={handleSearch} className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <Input
                  className="block w-full pl-11 pr-4 py-2.5 border-gray-300 dark:border-gray-600 rounded-full bg-gray-50 dark:bg-gray-800 focus:outline-none focus:bg-white dark:focus:bg-gray-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-800 transition-all"
                  placeholder="Search jobs, companies, people..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map(({ href, icon: Icon, label }) => (
              <Link key={href} href={href}>
                <div className={`flex flex-col items-center px-4 py-2 rounded-lg cursor-pointer transition-all duration-200 ${
                  location === href 
                    ? "text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30" 
                    : "text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-50 dark:hover:bg-gray-800"
                }`}>
                  <Icon className="h-5 w-5" />
                  <span className="text-xs mt-1 font-medium">{label}</span>
                </div>
              </Link>
            ))}
            
            {/* Notifications */}
            <div className="relative">
              <Button variant="ghost" size="sm" className="flex flex-col items-center px-4 py-2 h-auto rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800">
                <Bell className="h-5 w-5" />
                <span className="text-xs mt-1 font-medium">Alerts</span>
                {unreadCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 text-xs flex items-center justify-center p-0 rounded-full"
                  >
                    {unreadCount}
                  </Badge>
                )}
              </Button>
            </div>
          </div>

          {/* Profile and Wallet */}
          <div className="flex items-center space-x-3 ml-6">
            {/* Wallet Connection */}
            {wallet.isConnected ? (
              <Button variant="outline" size="sm" className="hidden sm:flex items-center space-x-2 border-indigo-200 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-900/30">
                <Wallet className="h-4 w-4" />
                <span className="hidden lg:inline font-mono text-sm">
                  {wallet.address?.slice(0, 6)}...{wallet.address?.slice(-4)}
                </span>
              </Button>
            ) : (
              <Button 
                onClick={connectWallet}
                size="sm" 
                className="hidden sm:flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-sm"
              >
                <Wallet className="h-4 w-4" />
                <span className="hidden lg:inline">Connect Wallet</span>
              </Button>
            )}
            
            {/* Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full ring-2 ring-gray-200 dark:ring-gray-700 hover:ring-indigo-300 dark:hover:ring-indigo-600 transition-all">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user?.profileImage} alt={user?.name} />
                    <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold">
                      {user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-64 shadow-xl border-gray-200 dark:border-gray-700" align="end" forceMount>
                <div className="flex items-center justify-start gap-3 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={user?.profileImage} alt={user?.name} />
                    <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold">
                      {user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col space-y-1 leading-none">
                    <p className="font-semibold text-gray-900 dark:text-white">{user?.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400 truncate max-w-[180px]">
                      {user?.email}
                    </p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild className="hover:bg-indigo-50 dark:hover:bg-indigo-900/30">
                  <Link href="/profile" className="flex items-center py-2">
                    <User className="mr-3 h-4 w-4" />
                    <span>View Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="hover:bg-red-50 dark:hover:bg-red-900/30 text-red-600 dark:text-red-400">
                  <LogOut className="mr-3 h-4 w-4" />
                  <span>Sign Out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* Mobile Search */}
      <div className="md:hidden px-4 pb-4 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <form onSubmit={handleSearch} className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <Input
            className="block w-full pl-11 pr-4 py-2.5 border-gray-300 dark:border-gray-600 rounded-full bg-white dark:bg-gray-700"
            placeholder="Search jobs, companies, people..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </form>
      </div>
    </nav>
  );
}
