import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Job } from "@/types";
import { 
  Bot, 
  Brain, 
  Upload, 
  Wallet, 
  TrendingUp, 
  MapPin,
  Building,
  Clock,
  Circle
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useWeb3 } from "@/hooks/use-web3";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function AIRecommendations() {
  const { user } = useAuth();
  const { wallet, connectWallet } = useWeb3();
  const { toast } = useToast();
  const [isExtracting, setIsExtracting] = useState(false);

  const { data: jobs = [] } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
    enabled: !!user,
  });

  // Get AI recommended jobs (simulate by filtering featured/high-match jobs)
  const recommendedJobs = jobs
    .filter(job => job.isFeatured || job.skills.some(skill => 
      user?.skills.some(userSkill => 
        userSkill.toLowerCase().includes(skill.toLowerCase()) ||
        skill.toLowerCase().includes(userSkill.toLowerCase())
      )
    ))
    .slice(0, 3);

  const handleSkillExtraction = async () => {
    const text = prompt("Paste your resume text or bio for AI skill extraction:");
    if (!text?.trim()) return;

    setIsExtracting(true);
    try {
      const response = await fetch('/api/ai/extract-skills', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ text }),
      });

      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Skills extracted successfully",
          description: `Found ${data.skills.length} relevant skills. Update your profile to add them.`,
        });
      } else {
        throw new Error('Failed to extract skills');
      }
    } catch (error) {
      toast({
        title: "Extraction failed",
        description: "Unable to extract skills. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExtracting(false);
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 75) return "text-yellow-600";
    return "text-gray-600";
  };

  const getMatchScoreBg = (score: number) => {
    if (score >= 90) return "bg-green-50";
    if (score >= 75) return "bg-yellow-50";
    return "bg-gray-50";
  };

  // Simulate match scores based on skill overlap
  const calculateMatchScore = (job: Job) => {
    if (!user?.skills.length) return 65;
    
    const userSkills = user.skills.map(s => s.toLowerCase());
    const jobSkills = job.skills.map(s => s.toLowerCase());
    const matchingSkills = userSkills.filter(skill => 
      jobSkills.some(jobSkill => 
        jobSkill.includes(skill) || skill.includes(jobSkill)
      )
    );
    
    const baseScore = Math.min(95, Math.max(60, (matchingSkills.length / Math.max(jobSkills.length, 1)) * 100));
    return Math.round(baseScore + (job.isFeatured ? 5 : 0));
  };

  return (
    <div className="space-y-6">
      {/* AI Job Recommendations */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Bot className="w-5 h-5 text-indigo-600" />
            <CardTitle className="text-base">AI Recommendations</CardTitle>
          </div>
          <p className="text-xs text-gray-500">Powered by machine learning</p>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {recommendedJobs.length > 0 ? (
            recommendedJobs.map((job) => {
              const matchScore = calculateMatchScore(job);
              return (
                <div key={job.id} className="flex items-start space-x-3">
                  <Avatar className="w-10 h-10 rounded">
                    <AvatarImage src={job.companyLogo} />
                    <AvatarFallback className="text-xs bg-gray-100">
                      {job.company.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <h5 className="text-sm font-medium text-gray-900 truncate">
                      {job.title}
                    </h5>
                    <div className="flex items-center gap-1 text-xs text-gray-600 mt-0.5">
                      <Building className="w-3 h-3" />
                      <span>{job.company}</span>
                    </div>
                    {job.location && (
                      <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
                        <MapPin className="w-3 h-3" />
                        <span>{job.location}</span>
                      </div>
                    )}
                    <div className="flex items-center mt-2">
                      <Badge 
                        className={`${getMatchScoreBg(matchScore)} ${getMatchScoreColor(matchScore)} border-0 text-xs px-2 py-0.5`}
                      >
                        {matchScore}% match
                      </Badge>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-4">
              <Bot className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600">No recommendations available</p>
              <p className="text-xs text-gray-500">Complete your profile for better matches</p>
            </div>
          )}
        </CardContent>
        
        {recommendedJobs.length > 0 && (
          <div className="px-6 pb-4">
            <Button variant="ghost" className="w-full text-primary text-sm hover:text-primary/80">
              View all recommendations
            </Button>
          </div>
        )}
      </Card>

      {/* Skill Extraction Tool */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Brain className="w-5 h-5 text-blue-600" />
            <CardTitle className="text-base">Skill Extractor</CardTitle>
          </div>
          <p className="text-xs text-gray-500">AI-powered skill detection</p>
        </CardHeader>
        
        <CardContent>
          <div className="border-dashed border-2 border-gray-200 rounded-lg p-6 text-center">
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-2">Upload your resume</p>
            <p className="text-xs text-gray-500 mb-3">AI will extract your skills automatically</p>
            <Button 
              onClick={handleSkillExtraction}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700"
              disabled={isExtracting}
            >
              {isExtracting ? "Extracting..." : "Choose File"}
            </Button>
          </div>
          
          {user?.skills && user.skills.length > 0 && (
            <div className="mt-4">
              <h5 className="text-sm font-medium text-gray-900 mb-2">Recently Extracted:</h5>
              <div className="flex flex-wrap gap-1">
                {user.skills.slice(0, 5).map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-xs">
                    {skill}
                  </Badge>
                ))}
                {user.skills.length > 5 && (
                  <Badge variant="outline" className="text-xs">
                    +{user.skills.length - 5} more
                  </Badge>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Web3 Wallet Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Wallet className="w-5 h-5 text-indigo-600" />
            <CardTitle className="text-base">Wallet Status</CardTitle>
          </div>
        </CardHeader>
        
        <CardContent>
          {wallet.isConnected ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Connection</span>
                <div className="flex items-center text-green-600 text-sm">
                  <Circle className="w-2 h-2 fill-current mr-1" />
                  Connected
                </div>
              </div>
              
              <div className="space-y-2 text-sm">
                <div>
                  <p className="text-gray-600">Network</p>
                  <p className="font-medium">{wallet.network || 'Unknown'}</p>
                </div>
                
                <div>
                  <p className="text-gray-600">Balance</p>
                  <p className="font-medium">{wallet.balance || '0.0000 ETH'}</p>
                </div>
                
                <div>
                  <p className="text-gray-600">Address</p>
                  <p className="font-mono text-xs text-gray-800 break-all">
                    {wallet.address}
                  </p>
                </div>
              </div>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full mt-4"
              >
                View Transactions
              </Button>
            </div>
          ) : (
            <div className="text-center space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Connection</span>
                <div className="flex items-center text-gray-400 text-sm">
                  <Circle className="w-2 h-2 fill-current mr-1" />
                  Disconnected
                </div>
              </div>
              
              <p className="text-gray-600 text-sm">Connect your wallet to enable Web3 features</p>
              <Button 
                onClick={connectWallet}
                size="sm"
                className="w-full bg-indigo-600 hover:bg-indigo-700"
              >
                Connect Wallet
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Market Insights */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-yellow-600" />
            <CardTitle className="text-base">Market Insights</CardTitle>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm text-gray-600">Web3 Jobs Growth</span>
              <span className="text-sm font-medium text-green-600">+47%</span>
            </div>
            <Progress value={85} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm text-gray-600">Average Salary</span>
              <span className="text-sm font-medium text-primary">$125k</span>
            </div>
            <Progress value={75} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm text-gray-600">Remote Opportunities</span>
              <span className="text-sm font-medium text-blue-600">78%</span>
            </div>
            <Progress value={78} className="h-2" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
