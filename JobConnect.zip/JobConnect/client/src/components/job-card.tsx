import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Job } from "@/types";
import { MapPin, Clock, DollarSign, Users, Star, Coins } from "lucide-react";
import PaymentModal from "./payment-modal";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";

interface JobCardProps {
  job: Job;
  showMatchScore?: boolean;
}

export default function JobCard({ job, showMatchScore = false }: JobCardProps) {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const { user } = useAuth();

  const { data: matchScore } = useQuery({
    queryKey: ["/api/jobs", job.id, "match"],
    enabled: !!user && showMatchScore,
    queryFn: async () => {
      const response = await fetch(`/api/jobs/${job.id}/match`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });
      return response.json();
    },
  });

  const formatSalary = () => {
    if (job.salaryMin && job.salaryMax) {
      return `$${(job.salaryMin / 1000).toFixed(0)}k - $${(job.salaryMax / 1000).toFixed(0)}k`;
    }
    if (job.salaryMin) {
      return `$${(job.salaryMin / 1000).toFixed(0)}k+`;
    }
    return "Salary not specified";
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600 bg-green-50";
    if (score >= 75) return "text-yellow-600 bg-yellow-50";
    return "text-gray-600 bg-gray-50";
  };

  const handleApply = () => {
    if (job.applicationFee) {
      setShowPaymentModal(true);
    } else {
      // Direct application without payment
      console.log("Applying to job:", job.id);
    }
  };

  return (
    <>
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-6">
          <div className="flex items-start space-x-4">
            {/* Company Logo */}
            <Avatar className="w-16 h-16 rounded-lg">
              <AvatarImage src={job.companyLogo} />
              <AvatarFallback className="rounded-lg bg-gray-100">
                {job.company.charAt(0)}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 truncate">
                    {job.title}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {job.company}
                    {job.location && (
                      <>
                        <span className="mx-2">•</span>
                        <span className="flex items-center inline">
                          <MapPin className="w-3 h-3 mr-1" />
                          {job.location}
                        </span>
                      </>
                    )}
                    {job.remote && (
                      <>
                        <span className="mx-2">•</span>
                        <span className="text-green-600">Remote</span>
                      </>
                    )}
                    <span className="mx-2">•</span>
                    <span className="flex items-center inline">
                      <Clock className="w-3 h-3 mr-1" />
                      {new Date(job.createdAt).toLocaleDateString()}
                    </span>
                  </p>
                </div>
                
                {showMatchScore && matchScore && (
                  <div className="flex items-center space-x-2">
                    <Badge className={`${getMatchScoreColor(matchScore.matchScore)} border-0`}>
                      {matchScore.matchScore}% Match
                    </Badge>
                    {matchScore.matchScore >= 85 && (
                      <Star className="w-4 h-4 text-yellow-500" title="AI Recommended" />
                    )}
                  </div>
                )}
              </div>
              
              <p className="text-gray-700 mt-3 line-clamp-3">
                {job.description}
              </p>
              
              {/* Skills */}
              {job.skills.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {job.skills.slice(0, 6).map((skill) => (
                    <Badge key={skill} variant="secondary" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                  {job.skills.length > 6 && (
                    <Badge variant="outline" className="text-xs">
                      +{job.skills.length - 6} more
                    </Badge>
                  )}
                </div>
              )}
              
              {/* Job Details */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span className="flex items-center">
                    <DollarSign className="w-4 h-4 mr-1" />
                    {formatSalary()}
                  </span>
                  <span>•</span>
                  <span className="capitalize">{job.jobType}</span>
                  {job.applicationFee && (
                    <>
                      <span>•</span>
                      <span className="flex items-center text-indigo-600">
                        <Coins className="w-4 h-4 mr-1" />
                        {job.applicationFee} {job.feeToken} to apply
                      </span>
                    </>
                  )}
                </div>
                
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    Save
                  </Button>
                  <Button onClick={handleApply} size="sm">
                    Apply Now
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {showPaymentModal && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          job={job}
          onPaymentSuccess={() => {
            setShowPaymentModal(false);
            // Handle successful payment and job application
            console.log("Payment successful, applying to job:", job.id);
          }}
        />
      )}
    </>
  );
}
