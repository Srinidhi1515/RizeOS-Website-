import { useState } from "react";
import { useWeb3 } from "@/hooks/use-web3";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  Wallet, 
  ExternalLink, 
  Copy, 
  CheckCircle, 
  AlertCircle,
  Circle,
  Coins,
  Activity
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Web3WalletProps {
  showBalance?: boolean;
  showTransactions?: boolean;
  compact?: boolean;
}

export default function Web3Wallet({ 
  showBalance = true, 
  showTransactions = false,
  compact = false 
}: Web3WalletProps) {
  const { wallet, connectWallet, disconnectWallet, isConnecting } = useWeb3();
  const { toast } = useToast();
  const [showConnectionDialog, setShowConnectionDialog] = useState(false);
  const [copied, setCopied] = useState(false);

  const copyAddress = async () => {
    if (wallet.address) {
      await navigator.clipboard.writeText(wallet.address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Address copied",
        description: "Wallet address copied to clipboard"
      });
    }
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const getNetworkColor = (network: string | null) => {
    if (!network) return "bg-gray-100 text-gray-600";
    if (network.includes("Mainnet")) return "bg-green-100 text-green-700";
    if (network.includes("Testnet")) return "bg-yellow-100 text-yellow-700";
    return "bg-blue-100 text-blue-700";
  };

  if (compact) {
    return (
      <div className="flex items-center space-x-2">
        {wallet.isConnected ? (
          <Button variant="outline" size="sm" className="flex items-center space-x-2">
            <Circle className="w-2 h-2 fill-green-500 text-green-500" />
            <Wallet className="w-4 h-4" />
            <span className="hidden sm:inline">{formatAddress(wallet.address!)}</span>
          </Button>
        ) : (
          <Button 
            onClick={() => setShowConnectionDialog(true)}
            size="sm"
            className="bg-indigo-600 hover:bg-indigo-700"
            disabled={isConnecting}
          >
            <Wallet className="w-4 h-4 mr-2" />
            {isConnecting ? "Connecting..." : "Connect"}
          </Button>
        )}
      </div>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Wallet className="w-5 h-5 text-indigo-600" />
              <span>Web3 Wallet</span>
            </div>
            {wallet.isConnected && (
              <Badge className={getNetworkColor(wallet.network)}>
                {wallet.network || 'Unknown'}
              </Badge>
            )}
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {wallet.isConnected ? (
            <>
              {/* Connection Status */}
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Status</span>
                <div className="flex items-center text-green-600 text-sm">
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Connected
                </div>
              </div>

              {/* Address */}
              <div className="space-y-2">
                <span className="text-sm text-gray-600">Address</span>
                <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                  <code className="text-xs font-mono text-gray-800 break-all">
                    {wallet.address}
                  </code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={copyAddress}
                    className="ml-2 flex-shrink-0"
                  >
                    {copied ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>

              {/* Balance */}
              {showBalance && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Balance</span>
                  <div className="flex items-center space-x-1">
                    <Coins className="w-4 h-4 text-yellow-600" />
                    <span className="font-medium">{wallet.balance || '0.0000 ETH'}</span>
                  </div>
                </div>
              )}

              <Separator />

              {/* Actions */}
              <div className="space-y-2">
                {showTransactions && (
                  <Button variant="outline" className="w-full" size="sm">
                    <Activity className="w-4 h-4 mr-2" />
                    View Transactions
                    <ExternalLink className="w-3 h-3 ml-2" />
                  </Button>
                )}
                
                <Button 
                  variant="outline" 
                  onClick={disconnectWallet}
                  className="w-full"
                  size="sm"
                >
                  Disconnect Wallet
                </Button>
              </div>
            </>
          ) : (
            <>
              {/* Disconnected State */}
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    <Wallet className="w-8 h-8 text-gray-400" />
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Connect Your Wallet</h4>
                  <p className="text-sm text-gray-600">
                    Connect your Web3 wallet to enable payments and blockchain features
                  </p>
                </div>

                <Button 
                  onClick={() => setShowConnectionDialog(true)}
                  className="w-full bg-indigo-600 hover:bg-indigo-700"
                  disabled={isConnecting}
                >
                  {isConnecting ? "Connecting..." : "Connect Wallet"}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Connection Dialog */}
      <Dialog open={showConnectionDialog} onOpenChange={setShowConnectionDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Connect Wallet</DialogTitle>
            <DialogDescription>
              Choose your preferred wallet to connect to JobConnect
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-3">
            {/* MetaMask */}
            <Button
              variant="outline"
              className="w-full justify-start h-16"
              onClick={async () => {
                await connectWallet();
                setShowConnectionDialog(false);
              }}
              disabled={isConnecting}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-white" />
                </div>
                <div className="text-left">
                  <div className="font-medium">MetaMask</div>
                  <div className="text-sm text-gray-500">Connect using MetaMask wallet</div>
                </div>
              </div>
            </Button>

            {/* Phantom */}
            <Button
              variant="outline"
              className="w-full justify-start h-16"
              onClick={async () => {
                await connectWallet();
                setShowConnectionDialog(false);
              }}
              disabled={isConnecting}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-white" />
                </div>
                <div className="text-left">
                  <div className="font-medium">Phantom</div>
                  <div className="text-sm text-gray-500">Connect using Phantom wallet</div>
                </div>
              </div>
            </Button>

            {/* Warning */}
            <div className="flex items-start space-x-2 p-3 bg-yellow-50 rounded-lg">
              <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium">Testnet Only</p>
                <p>This application uses testnet tokens. No real money is involved.</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
