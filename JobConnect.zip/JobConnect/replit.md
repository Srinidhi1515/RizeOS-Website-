# JobConnect - Web3 Job & Networking Portal

## Overview

JobConnect is a full-stack professional networking and job portal platform that combines traditional job marketplace features with modern Web3 functionality and AI-powered enhancements. The application serves as a LinkedIn-inspired platform where users can create profiles, post and discover jobs, connect with other professionals, and utilize blockchain payments for premium features.

The platform integrates three key technology pillars: traditional web development for core functionality, Web3 blockchain integration for payments and wallet connectivity, and AI/ML capabilities for intelligent job matching and skill extraction. Users can post jobs with blockchain-based application fees, get AI-powered job recommendations, and connect their crypto wallets for seamless Web3 interactions.

## Recent Changes (January 2025)

### Professional Layout Redesign
- Completely redesigned the user interface with a modern, corporate-style layout
- Added gradient hero section with personalized welcome message and feature highlights
- Enhanced navbar with improved branding, professional styling, and enhanced search functionality
- Redesigned profile sidebar with visual stats, AI match scoring, and actionable quick actions
- Implemented professional color scheme using indigo/purple gradients
- Added sticky sidebar elements and improved responsive design

### Sample Data Population
- Added 5 realistic job postings with detailed descriptions, salary ranges, and skill requirements
- Created sample user profiles representing different professional roles (engineers, designers, product managers)
- Populated connection network with professional relationships and mutual connection counts
- Added sample social feed posts demonstrating professional networking content
- Integrated AI match scores and professional verification badges

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built using React 18 with TypeScript, leveraging Vite as the build tool for fast development and optimized production builds. The UI framework uses shadcn/ui components built on top of Radix UI primitives, providing a consistent and accessible design system. Tailwind CSS handles styling with a custom design token system supporting both light and dark themes.

State management follows a modern approach using React Query (TanStack Query) for server state management, React Context for global application state (authentication and Web3), and local useState for component-level state. The routing system uses Wouter as a lightweight client-side router.

The component architecture separates concerns into pages, reusable components, UI primitives, custom hooks, and utility functions. Key architectural patterns include custom hooks for authentication (`use-auth`) and Web3 functionality (`use-web3`), compound component patterns for complex UI elements, and a centralized query client for API communication.

### Backend Architecture
The server-side follows a REST API architecture built with Express.js and TypeScript. The application uses a layered architecture pattern with clear separation between route handlers, business logic, and data access layers.

The API layer is organized into modular route handlers with middleware for authentication (JWT-based), request validation, and error handling. Authentication uses JSON Web Tokens with bcrypt for password hashing, providing secure user session management.

The data access layer implements a repository pattern through a storage abstraction (`IStorage` interface), allowing for clean separation between business logic and database operations. This pattern provides flexibility for future database changes and makes testing easier.

### Database Design
The application uses PostgreSQL as the primary database with Drizzle ORM for type-safe database operations. The database connection utilizes Neon's serverless PostgreSQL with connection pooling for optimal performance.

The schema design includes core entities: Users (profiles, authentication, skills), Jobs (postings, requirements, payment info), Posts (social feed content), Applications (job applications), Connections (professional networking), and Notifications (user alerts). The schema uses UUID primary keys, proper foreign key relationships, and includes audit fields (created_at, updated_at) for all entities.

Key design decisions include storing skills as PostgreSQL arrays for flexible skill management, using JSONB for extensible metadata storage, and implementing soft deletes for data retention where appropriate.

### Authentication & Authorization
The system implements JWT-based authentication with secure token storage and validation. User registration includes password strength requirements with bcrypt hashing (salt rounds: 10). The authentication flow supports user registration, login, logout, and automatic token refresh.

Authorization uses middleware-based route protection with role-based access control for admin functions. The system includes user profile verification status and implements secure session management with token expiration handling.

### Web3 Integration
The blockchain integration supports multiple networks (Ethereum, Polygon, Solana) with wallet connectivity through MetaMask and Phantom wallets. The Web3 architecture includes wallet connection management, transaction signing and verification, and payment processing for job posting fees.

Key components include a Web3 context provider for wallet state management, transaction validation services, and gas fee estimation utilities. The system implements blockchain payment verification before allowing premium actions like job posting, with transaction hash storage for audit trails.

### AI/ML Features
The AI integration leverages OpenAI's GPT-4 model for intelligent features including job-to-candidate matching algorithms, automated skill extraction from resumes/bios, and personalized job recommendations. The AI services are implemented as separate modules with error handling and fallback mechanisms.

The matching algorithm considers multiple factors: skill alignment (40% weight), location compatibility (20%), experience level (20%), job type preference (10%), and industry/domain match (10%). Results include match scores, reasoning explanations, and improvement recommendations.

### External Service Integration
The application integrates with several external services: OpenAI API for AI-powered features, Neon Database for serverless PostgreSQL hosting, and blockchain networks (Ethereum/Polygon/Solana) for Web3 functionality.

The integration architecture uses environment-based configuration, proper error handling with retry mechanisms, and service abstraction layers for easy testing and maintenance.

## External Dependencies

### Core Framework Dependencies
- **React 18**: Frontend framework with hooks and concurrent features
- **TypeScript**: Type safety across frontend and backend
- **Node.js/Express**: Backend API server framework
- **Vite**: Frontend build tool and development server

### Database & ORM
- **PostgreSQL**: Primary database (via Neon serverless)
- **Drizzle ORM**: Type-safe database toolkit and query builder
- **@neondatabase/serverless**: Serverless PostgreSQL connection driver

### UI & Styling
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Component library built on Radix UI
- **Radix UI**: Unstyled, accessible UI primitives
- **Lucide React**: Icon library

### Authentication & Security
- **JSON Web Tokens (jsonwebtoken)**: Token-based authentication
- **bcrypt**: Password hashing and validation
- **connect-pg-simple**: PostgreSQL session store

### State Management & Data Fetching
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Zod**: Runtime type validation and schema definition

### Web3 & Blockchain
- **@solana/web3.js**: Solana blockchain integration
- **Web3.js/Ethers.js**: Ethereum/Polygon blockchain interaction
- **MetaMask/Phantom**: Wallet connection and transaction signing

### AI & Machine Learning
- **OpenAI API**: GPT-4 integration for AI features
- **Natural Language Processing**: Skill extraction and job matching

### Development & Build Tools
- **ESBuild**: Fast JavaScript bundler for production
- **PostCSS**: CSS processing and optimization
- **Autoprefixer**: CSS vendor prefix automation

### Routing & Navigation
- **Wouter**: Lightweight client-side router
- **React Router patterns**: Navigation state management

### Utility Libraries
- **clsx**: Conditional className utility
- **class-variance-authority**: Component variant management
- **date-fns**: Date manipulation and formatting
- **nanoid**: Unique ID generation